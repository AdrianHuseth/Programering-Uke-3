from PIL import Image, ImageFont, ImageDraw
import os
import time

def intro():
    print("\nHei og velkommen til BOB bilderedigerer.\n")
    rediger_bilde()

def rediger_bilde():
    global bilde
    bilde_navn = input("Skriv inn navnet på bildet du ønsker å redigere (inkluder filtypen som '.jpg') OBS! Bildet må være i samme mappe som dette programmet: ")

    try:
        bilde = Image.open(bilde_navn)
    except FileNotFoundError:
        print("Bilde ikke funnet.\n")
        rediger_bilde()

    spørsmål1()

def spørsmål1():
    global bilde
    print("\nHva ønsker du å gjøre med bildet ditt?: \n")
    print("(1) Legge til et instagramfilter.")
    print("(2) Gjøre bildet sort og hvitt.")
    print("(3) Rotere bildet.")
    print("(4) Rescale bildet til å ha 1080 pixler i bredden.")
    print("(5) Gjøre bildet 'retro'.")
    print("(6) Gjøre bildet om til et bursdagskort.")
    print("")

    svar = input("")
    print("")

    if svar == "1":
        instagram_filter()

    elif svar == "2":
        redigert_bilde = bilde.convert("L")
        redigert_bilde.show()
        lagre_bilde(redigert_bilde)

    elif svar == "3":
        print("")
        print("Hvor mye ønsker du å rotere bildet?:")
        print("(1) -90 grader.")
        print("(2) 90 grader.")
        print("(3) 180 grader.")
        print("")
        valg = input("")
        print("")

        if valg == "1":
            rotert_bilde = bilde.rotate(90)
            rotert_bilde.show()
            lagre_bilde(rotert_bilde)
        elif valg == "2":
            rotert_bilde = bilde.rotate(-90)
            rotert_bilde.show()
            lagre_bilde(rotert_bilde)
        elif valg == "3":
            rotert_bilde = bilde.rotate(180)
            rotert_bilde.show()
            lagre_bilde(rotert_bilde)
        else:
            print("Ugyldig valg.")
            print("")
            spørsmål1()

    elif svar == "4":
        opprinnelig_bredde, opprinnelig_høyde = bilde.size
        ny_bredde = 1080
        ny_høyde = int((ny_bredde / opprinnelig_bredde) * opprinnelig_høyde)
        endret_bilde = bilde.resize((ny_bredde, ny_høyde))
        endret_bilde.show()
        lagre_bilde(endret_bilde)

    elif svar == "5":
        crop_and_scale("polaroid-frame.jpg")

    elif svar == "6":
        lag_bursdagskort()

    else:
        print("Ugyldig valg. Prøv igjen.\n")
        spørsmål1()

def crop_and_scale(frame_image_path):
    global bilde
    original_image = bilde

    width, height = original_image.size
    if width > height:
        new_width = height
        new_height = height
    else:
        new_width = width
        new_height = width

    left = (width - new_width) / 2
    top = (height - new_height) / 2
    right = (width + new_width) / 2
    bottom = (height + new_height) / 2

    cropped_image = original_image.crop((left, top, right, bottom))

    target_size = (760, 760)
    scaled_image = cropped_image.resize(target_size, Image.LANCZOS)

    frame = Image.open(frame_image_path)

    frame.paste(scaled_image, (64, 64))

    frame.show()

    lagre_bilde(frame)

def instagram_filter():
    global bilde
    
    pixels = bilde.load()
    width, height = bilde.size

    for y in range(height):
        for x in range(width):
            r, g, b = bilde.getpixel((x, y))
            r = min(255, int(1.2 * r))
            g = max(0, int(0.8 * g))
            pixels[x, y] = (r, g, b)

    bilde.show()

    lagre_bilde(bilde)

def lag_bursdagskort():
    global bilde
    bursdags_hilsen = "Gratulerer med dagen!"

    bursdag_bilde = bilde.copy()

    font = ImageFont.truetype("arialbd.ttf", 100)

    draw = ImageDraw.Draw(bursdag_bilde)

    text_width, text_height = draw.textsize(bursdags_hilsen, font=font)

    image_width, image_height = bursdag_bilde.size
    text_x = (image_width - text_width) / 2
    text_y = (image_height - text_height) / 2

    draw.text((text_x, text_y), bursdags_hilsen, fill="orange", font=font)

    bursdag_bilde.show()

    lagre_bilde(bursdag_bilde)

def lagre_bilde(endret_bilde):
    print("")
    nytt_navn = input("Hva vil du kalle dette nye bildet?: ") + ".png"
    print("")
    mappe = os.path.dirname(os.path.realpath(__file__))
    bilde_sti = os.path.join(mappe, nytt_navn)
    endret_bilde.save(bilde_sti)
    print(f"Bildet er nå blitt lagret som '{nytt_navn}' i mappen '{mappe}'.\n")
    
    omstart()

def omstart():
    print("")
    svar = input("Ønsker du å redigere enda ett bilde? (y/n): ")
    print("")
    if svar == "y":
        intro()

    elif svar == "n":
        print("Den er god, takk for at du tok til bruk BOBs bilderedigerer :). ")
        print("")
        print("Credits:")
        print("Kode laget av Adrian P. Huseth")
        time.sleep(8)
        quit()
    
    else:
        print("Ugyldig svar. Prøv igjen. ")
        print("")
        omstart()

intro()
