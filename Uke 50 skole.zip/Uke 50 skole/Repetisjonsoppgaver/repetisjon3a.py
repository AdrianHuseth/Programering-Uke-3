
def kalkulator():
    x = int(input("Skriv ett tall: "))
    y = int(input("Skriv ett tall til: "))
    print("")

    a = x + y
    if x or y != range(-100000000000000000000000000000000,1000000000000000000000000000000000):
        print("Ikke gyldig, prøv på nytt!")
        print("")
        kalkulator()

    else:
        print("Summen av", x,"+", y,"=", a)

kalkulator()
