
total = 0

for i in range(1,101):
    total += i

print("Hvis du adderer alle tallene mellom 1-100 så får du", total)
