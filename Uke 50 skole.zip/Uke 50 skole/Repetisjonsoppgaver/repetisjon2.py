
num = 2

while num <= 30:
    print(num)
    num += 2
