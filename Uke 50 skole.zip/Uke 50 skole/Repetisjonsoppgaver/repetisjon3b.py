
def gjennomsnitt(tall_liste):
    return sum(tall_liste) / len(tall_liste) if tall_liste else 0

tall_liste = [3, 5, 38, 43, 54]
gjennomsnittet = gjennomsnitt(tall_liste)
print("Gjennomsnittet er:", gjennomsnittet)
